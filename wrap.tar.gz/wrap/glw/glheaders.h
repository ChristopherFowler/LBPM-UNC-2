#ifndef GLW_GLHEADERS_H
#define GLW_GLHEADERS_H

#include <GL/glew.h>

#endif // GLW_GLHEADERS_H
